
var swiper = new Swiper(".mySwiper-listing", {
    pagination: {
      el: ".swiper-pagination",
      
    },
    navigation: {
      nextEl: ".listing-next",
      prevEl: ".listing-prev",
    },
  });